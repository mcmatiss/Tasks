<?php
//02 - IF, ELSE, ELSEIF & SWITCH

//Exercise 1
//Given variables (int) 10, string "10" determine if they both are the same.
$aInt = 10;
$aString = "10";

if ($aInt === $aString) {
    echo "They are the same.";
} else {
    echo "They are not the same.";
}
echo PHP_EOL;

//Exercise 2
//Given variable (int) 50, determine if its in the range of 1 and 100.
$bInt = 50;

if ($bInt >= 1 && $bInt <= 100) {
    echo "The given value ($bInt) is within the range of 1 and 100.";
} else {
    echo "The given value ($bInt) is not within the range of 1 and 100.";
}
echo PHP_EOL;

//Exercise 3
//Given variables (string) "hello" create a condition that if the given value is "hello" then output "world".
$cString = "hello";

if ($cString === "hello") {
    echo "world";
}
echo PHP_EOL;

//Exercise 4
//By your choice, create condition with 3 checks.
//For example, if value is greater than X, less than Y and is an even number.
$dValue = rand(0, 10);

if ($dValue > 2 && $dValue < 8 && $dValue % 2 === 0) {
    echo "Hit on target! ($dValue)";
} else {
    echo "Miss! ($dValue)";
}
echo PHP_EOL;

//Exercise 5
//Given variable (int) 50 create a condition that prints out "correct" if the variable is inside the range.
//Range should be stored within the 2 separated variables $y and $z.
$eInt = 50;
$y = 0;
$z = 200;

if ($eInt >= $y && $eInt <= $z){
    echo "correct";
}
echo PHP_EOL;

//Exercise 6
//Create a variable $plateNumber that stores your car plate number. Create a switch statement that prints out that its your car in case of your number.
$plateNumber = "CG-5534";

switch ($plateNumber) {
    case "AA-5093":
        echo "It is your car.";
        break;
    case "NZ-5565":
        echo "It is your car.";
        break;
    case "CG-5534":
        echo "It is your car.";
        break;
    case "HX-3498":
        echo "It is your car.";
        break;
}
echo PHP_EOL;

//Exercise 7
//Create a variable $number with integer by your choice. Create a switch statement that prints out text "low" if the value is under 50, "medium" if the case is higher than 50 but lower than 100, "high" if the value is >100.
$number = 20;

switch ($number) {
    case $number < 50:
        echo "low";
        break;
    case $number > 50 && $number < 100:
        echo "medium";
        break;
    case $number > 100:
        echo "high";
        break;
}