<?php
//01 - VARIABLES& DATA TYPES

//Exercise 1
//Create variable that prints out an integer 10, float 10.10, string "hello world"
$aInt = 10;
$aFloat = 10.10;
$aString = "hello world";
$aVariable = "$aInt $aFloat $aString";

echo $aVariable;
echo PHP_EOL;

//Exercise 2
//Dump the same values that should display both data type & its value. (Note, usage of var_dump)
var_dump($aInt);
var_dump($aFloat);
var_dump($aString);

//Exercise 3
//Concatenate your name, surname and integer of your age.
$myName = "Matīss";
$mySurname = "Vestmanis";
$myAge = 27;

echo $myName . " " . $mySurname . " " . $myAge;