<?php
//04 - Loops

//Exercise 1
//Create an array with integers (up to 10) and print them out using foreach loop.
$aArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

foreach ($aArray as $number) {
    echo "$number ";
}
echo PHP_EOL;

//Exercise 2
//Create an array with integers (up to 10) and print them out using for loop.
$bArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

for ($i = 0; $i < count($bArray); $i++) {
    echo "$bArray[$i] ";
}
echo PHP_EOL;

//Exercise 3
//Given variable $x = 1 while $x is lower than 10, print out text "codelex". (Note: To avoid infinite looping, after each print increase the variable $x by 1)
$x = 1;

while ($x < 10) {
    echo "codelex";
    $x++;
}
echo PHP_EOL;

//Exercise 4
//Create a non associative array with integers and print out only integers that divides by 3 without any left.
$dArray = [2, 33, 44, 55, 6, 77, 26, 30, 300, 3, 24];

foreach ($dArray as $number) {
    if($number % 3 === 0) {
        echo "$number ";
    }
}
echo PHP_EOL;

//Exercise 5
//Create an associative array with objects of multiple persons.
//Each person should have a name, surname, age and birthday. Using loop (by your choice) print out every persons personal data.
$personOne = new stdClass();
$personOne -> name = "Jānis";
$personOne -> surname = "Bērziņš";
$personOne -> age = 50;
$personOne -> birthday = "02/01/1974";
$personTwo = new stdClass();
$personTwo -> name = "Biruta";
$personTwo -> surname = "Ozoliņa";
$personTwo -> age = 41;
$personTwo -> birthday = "09/03/1983";
$personThree = new stdClass();
$personThree -> name = "Žanis";
$personThree -> surname = "Doe";
$personThree -> age = 30;
$personThree -> birthday = "25/04/1994";

$personsArray = [
    "first" => $personOne,
    "second" => $personTwo,
    "third" => $personThree
];

foreach ($personsArray as $person) {
    echo "$person->name $person->surname $person->age $person->birthday \n";
}